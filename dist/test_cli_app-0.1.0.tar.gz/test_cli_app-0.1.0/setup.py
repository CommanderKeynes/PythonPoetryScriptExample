# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['test_cli_app']

package_data = \
{'': ['*']}

install_requires = \
['click']

entry_points = \
{'console_scripts': ['test_cli_app = test_cli_app.awesome_cli_app:hello']}

setup_kwargs = {
    'name': 'test-cli-app',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Andrew Jackson',
    'author_email': 'ajackson324@gatech.edu',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
